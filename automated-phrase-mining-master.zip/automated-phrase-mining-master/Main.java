
package topictracking;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MainFrame mf=new MainFrame();
        mf.setVisible(true);
        mf.setTitle("Topic Tracking");
        mf.setResizable(false);
    }
}
