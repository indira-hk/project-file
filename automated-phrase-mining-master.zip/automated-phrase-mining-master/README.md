# automated-phrase-mining

# Short description of our project: 
The main aim of our project is identifying whether the Active and Passive English sentences are same or not using the Artificial Neural Network for Parts-of-speech tagging to identify the noun, verb and the adjective.
We provide two inputs sentences to the program i.e., active voice sentence and passive voice sentence, along with them we load the dataset containing the oxford dictionary (999,998 words) for identifying whether the words that we are providing are present in it or not.

# Project setup: 
For you to setup this project on your computer, you need the following:
1. Netbeans 7.3.1 or higher
2. Active internet connection

# Building the Project: 
To build this project on your computer, do make sure you have enabled Java and J2EE along with database MYSQL in Netbeans 7.3.1.
You should be able to get the project running on your computer

# Result:
Our project provides us with the output whether the two sentences that we provide are same or not.



